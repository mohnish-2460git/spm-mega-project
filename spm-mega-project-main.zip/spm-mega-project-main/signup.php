<!DOCTYPE html>

<html>

<head>

	<title>Mega Project</title>

	<script type="text/javascript" src="https://code.jquery.com/jquery-1.9.1.min.js"></script>

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

</head>

<body>

<div class="container">

  <h1>Signup</h1>

  <form role="form" id="contactForm" class="contact-form">

    <div class="alert alert-danger display-error" style="display: none">

    </div>

    <div class="form-group">

        <input type="email" class="form-control" id="email" placeholder="Email" >

    </div>

    <div class="form-group">

        <input type="password" id="password" class="form-control" placeholder="Password" >

    </div>

    <div class="form-group">

        <input type="password" id="confirm-password" class="form-control" placeholder="Confirm Password" >

    </div>

    <button type="submit" id="submit" class="btn btn-success">Signup</button>
    
    

  </form>

</div>


</body>


<script type="text/javascript">

  $(document).ready(function() {


      $('#submit').click(function(e){

        e.preventDefault();

        var email = $("#email").val();

        var password = $("#password").val();

        var confirm_password = $("#confirm-password").val();


        $.ajax({

            type: "POST",

            url: "assist/signup_process.php",

            dataType: "json",

            data: {email:email, password:password, confirm_password:confirm_password},

            cache: false,

            success : function(data){

                if (data.code == "200"){

                    location.href = data.msg;

                } else {

                    $(".display-error").html("<ul>"+data.msg+"</ul>");

                    $(".display-error").css("display","block");

                }

            }

        });


      });

  });

</script>

</html>