<?php

require_once "config.php";

$errorMSG = "";


/* EMAIL */

if (empty($_POST["email"])) {

    $errorMSG .= "<li><b>Email</b> is required</li>";

} else if(!filter_var($_POST["email"], FILTER_VALIDATE_EMAIL)) {

    $errorMSG .= "<li>Invalid <b>Email</b> format</li>";

}else {

    $email = $_POST["email"];

}


/* PASSWORD */

if (empty($_POST["password"])) {

    $errorMSG .= "<li><b>Password</b> is required</li>";

}else if(strlen($_POST["password"]) < 8){

    $errorMSG .= "<li><b>Password</b> requires minimum 8 characters.</li>";
}

else {

    $password = $_POST["password"];

}

/* CONFIRM PASSWORD */

if($_POST["password"] != $_POST["confirm_password"]){

    $errorMSG .= "<li><b>Password</b> does not match with <b>Confirm Password</b></li>";
}


if(empty($errorMSG)){

    $sql = "INSERT INTO users (email, password) VALUES (?, ?)";

    if($stmt = $mysqli->prepare($sql)){
        // Bind variables to the prepared statement as parameters
        $stmt->bind_param("ss", $param_email, $param_password);
        
        // Set parameters
        $param_email = $email;
        $param_password = $password;
        
        // Attempt to execute the prepared statement
        if($stmt->execute()){
            
            //change redirect url here after successful register
            $url = "practice.html";
            echo json_encode(['code'=>200, 'msg'=>$url]);

        } else{
            
            $errorMSG .= "<li>Error occured</li>";
            echo json_encode(['code'=>404, 'msg'=>$errorMSG]);
        }

        // Close statement
        $stmt->close();
    }

	exit;

}


echo json_encode(['code'=>404, 'msg'=>$errorMSG]);


?>